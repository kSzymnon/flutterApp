package com.example.lista_zakupowa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
