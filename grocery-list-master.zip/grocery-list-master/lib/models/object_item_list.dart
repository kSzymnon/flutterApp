class ObjectItemList {
  late final int amount;
  late final String item;
  late final bool collected;

  ObjectItemList(this.item, this.amount,this.collected);

  getItem() {
    return item;
  }

  getAmount() {
    return amount;
  }

  isCollected() {
    return collected;
  }

  setAmount(am) {
    amount = am;
  }

  setCollected(check) {
    collected = check;
  }
}
